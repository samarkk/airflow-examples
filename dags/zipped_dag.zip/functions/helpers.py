def first_task():
    print("Hello from first task")

def second_task():
    print("Hello from second task")

def third_task():
    print("Hello from third task")